/* 
  script.js — Demonstrates:
  - Scope (global vs local variables)
  - Parameters & return values in functions
  - Triggering animations via JS
*/

// Global variable
let box = document.getElementById("box");

// Function with parameter & return value
function addMessage(message) {
  let result = "System says: " + message;
  console.log(result);
  return result; // return value
}

// Function that starts animation
function startAnimation() {
  box.classList.add("animate");  // add CSS animation
  let feedback = addMessage("Animation started ✅"); // scope + return value
  alert(feedback); // show return value
}

// Function that stops animation
function stopAnimation() {
  box.classList.remove("animate");
  let feedback = addMessage("Animation stopped ⛔");
  alert(feedback);
}